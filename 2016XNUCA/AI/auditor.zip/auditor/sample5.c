#include <stdio.h>
#include <stdlib.h>
int sumup_2d(int *, int, int);
int readin_and_sumup_2d(int *, int, int);
int main(){
    int x, y, n, res;
    int *a;
    printf("input num of numbers\n");
    scanf("%d%d", &x, &y);
    res = readin_and_sumup_2d(a, x, y);
    printf("'sum' is %d\n", res);
    return 0;
}
int readin_and_sumup_2d(int *a, int x, int y){
    printf("input x*y numbers");
    int i, n;
    n = x*y;
    a = (int *) malloc(n*sizeof(int));
    for (i = 0; i<n; ++i)
        scanf("%d", a+i);
    return sumup_2d(a, x, y);
}
int sumup_2d(int *a, int x, int y){
    int i, j, t = 0;
    for (i = 0; i<x; ++i)
        for (j = 0; j<y; ++i)
            t += a[i*x+j]*i;
    return t;
}