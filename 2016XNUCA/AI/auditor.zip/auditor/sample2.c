#include <stdio.h>

void showhelp(char * s){
    printf(s);
}

void echo(){
    char usrinput[101];
    scanf("%100s", usrinput);
    printf(usrinput);
}

int main(){
    printf("input number to get service\n");
    puts("1 for help");
    puts("2 for echo");
    puts("3 for exit");
    int n;
    do{
        scanf("%d", &n);
    }while (n!=1&&n!=2&&n!=3);

    if (n==1)
        showhelp("simple program, just return your input");
    else if (n==2)
        echo();
    else if (n==3)
        printf("bye\n");
    return 0;
}