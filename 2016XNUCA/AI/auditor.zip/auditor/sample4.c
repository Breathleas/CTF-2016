#include <stdio.h>
#include <stdlib.h>
int sumup(int *, int);
int readin_and_sumup(int *, int);
int main(){
    int n, res;
    int *a;
    printf("input num of numbers\n");
    scanf("%d", &n);
    res = readin_and_sumup(a, n);
    printf("sum is %d\n", res);
    return 0;
}
int readin_and_sumup(int *a, int n){
    printf("input n numbers");
    int i;
    a = (int *) malloc(n*sizeof(int));
    for (i = 0; i<n; ++i)
        scanf("%d", a+i);
    return sumup(a, n);
}
int sumup(int *a, int n){
    int i, t = 0;
    for (i = 0; i<=n; ++i)
        t += a[i];
    return t;
}