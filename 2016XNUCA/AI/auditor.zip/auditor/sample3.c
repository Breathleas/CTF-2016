#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*another simple program 
 *return exactly user input?
 */
int main(){
    char *s = (char *) malloc(100);
    free(s);
    char *t = (char *) malloc(100);
    printf("a toy program to show the danger of UAF\n");
    puts("input your string");
    scanf("%51s", t);
    strcpy(s, "do you think you can get your stirng back? naive...");
    printf("%s\n", t);
    printf("but, don't expect our test case will be as naive as this one     ...\n");
    return 0;
}