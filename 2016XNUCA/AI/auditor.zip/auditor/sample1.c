#include <string.h>
#include <stdio.h>

/*this is an example login program
 *use strcpy(s, t); to get user input
 */

int login()
{
    char password[] = "password";
    char username[9];
    char inputpwd[9];
    printf ( "what's your name\n" );
    scanf ( "%s", username );
    printf ( "hello %s\n", username );
    printf ( "please input password\n" );
    scanf ( "%8s", inputpwd );
    if ( strcmp ( inputpwd, password ) == 0 )
    {
        return 1;
    }
    return 0;
}

int main()
{
    if ( login() )
    {
        puts ( "you login succ!\n" );
    }
    else
    {
        puts ( "sorry, you login fail!\n" );
        return 0;
    }
    puts ( "now show you some secret:\n" );
    puts ( "1+1=2\n" );
    return 0;
}
