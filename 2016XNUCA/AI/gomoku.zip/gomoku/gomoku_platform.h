#ifndef GOMOKU_PLATFORM_HEADER
#define GOMOKU_PLATFORM_HEADER

#include <stdio.h>

bool start_one_game ( FILE* challenger_stdin, FILE* challenger_stdout, FILE* defender_stdin, FILE* defender_stdout );

#endif
