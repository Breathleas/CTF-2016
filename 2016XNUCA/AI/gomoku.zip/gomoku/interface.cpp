#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include <unistd.h>
#include <signal.h>

#include "gomoku_platform.h"

struct popen2
{
    pid_t child_pid;
    int from_child, to_child;
};

struct popen2 child_st;

int popen2 ( const char* cmdline, struct popen2* childinfo )
{
    pid_t p;
    int pipe_stdin[2], pipe_stdout[2];
    if ( pipe ( pipe_stdin ) )
    {
        return -1;
    }
    if ( pipe ( pipe_stdout ) )
    {
        return -1;
    }
    //printf ( "pipe_stdin[0] = %d, pipe_stdin[1] = %d\n", pipe_stdin[0], pipe_stdin[1] );
    //printf ( "pipe_stdout[0] = %d, pipe_stdout[1] = %d\n", pipe_stdout[0], pipe_stdout[1] );
    p = fork();
    if ( p < 0 )
    {
        return p;    /* Fork failed */
    }
    if ( p == 0 ) /* child */
    {
        close ( pipe_stdin[1] );
        dup2 ( pipe_stdin[0], 0 );
        close ( pipe_stdout[0] );
        dup2 ( pipe_stdout[1], 1 );
        //execl ( "/bin/sh", "sh", "-c", cmdline, NULL );
        execl ( cmdline, cmdline, NULL );
        perror ( "execl" );
        _exit ( 99 );
    }
    childinfo->child_pid = p;
    childinfo->to_child = pipe_stdin[1];
    childinfo->from_child = pipe_stdout[0];
    return 0;
}

int score = 0;

void kill_child()
{
    kill ( child_st.child_pid, SIGTERM );
}

void alarm_handler ( int signo )
{
    ( void ) signo;
    fprintf ( stderr, "SCORE:[%d]\n", score );
    kill_child ();
    exit ( 0 );
}

int main ( int argc, char* argv[] )
{
    if ( argc != 2 )
    {
        //ARG_FAIL:
        fprintf ( stderr, "Usage: %s [defender_ai_path]\n", argv[0] );
        return -1;
    }
    if ( signal ( SIGALRM, alarm_handler ) == SIG_ERR )
    {
        fprintf ( stderr, "Failed to set the alarm!\n" );
        return -1;
    }
    int errno = popen2 ( argv[1], &child_st );
    if ( errno )
    {
        return errno;
    }
    srand ( time ( 0 ) );
    FILE* child_stdin = fdopen ( child_st.from_child, "r" );
    FILE* child_stdout = fdopen ( child_st.to_child, "w" );
    alarm ( 60 * 30 );
    setvbuf ( stdin, NULL, _IONBF, 0 );
    setvbuf ( stdout, NULL, _IONBF, 0 );
    setvbuf ( child_stdin, NULL, _IONBF, 0 );
    setvbuf ( child_stdout, NULL, _IONBF, 0 );
    const int WAVES = 5;
    for ( int i = 0; i < WAVES; i++ )
    {
        if ( start_one_game ( stdin, stdout, child_stdin, child_stdout ) )
        {
            //fprintf ( stderr, "Challenger wins game #%d\n", i );
            score += 1000 / WAVES;
            if ( score > 1000 )
            {
                score = 1000;
            }
        }
    }
    printf ( "Your score: %d. Congratulations~\n", score );
    alarm ( 60 );
    fprintf ( stderr, "SCORE:[%d]\n", score );
    kill_child ();
    return 0;
}
