#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

const char marker_str[10][32] =
{
    "[FIRST_3]",
    "[YOUR_OPINION]",
    "[YOUR_OPINION2]",
    "[YOU_BLACK]",
    "[YOU_WHITE]",
    "[GAME_OVER]"
};

char map[32][32];

int state;

struct first_3
{
    int x1;
    int y1;
    int x2;
    int y2;
    int x3;
    int y3;
};

struct opinion_1
{
    int opinion;
    int x4;
    int y4;
    int x5;
    int y5;
};

const char BLANK = 0, BLACK = 1, WHITE = 2, SUM = 3;

void resetMap();

void drop ( int x, int y, int t );

void drop_first_3 ( first_3 f );

void drop_opinion_1 ( opinion_1 f );

first_3 generate_first_3();

opinion_1 generate_opinion_1();

int generate_opinion_2();

void ai_subloop ( int type );

struct point
{
    int x;
    int y;
};

point ai ( int type );

int strtype ( const char* str );

int main()
{
    setvbuf ( stdin, NULL, _IONBF, 0 );
    setvbuf ( stdout, NULL, _IONBF, 0 );
    state = 0;
    char buf[32];
    while ( scanf ( "%s", buf ) )
    {
        int t = strtype ( buf );
        //fprintf ( stderr, "[stderr]%s,%d\n", buf, t );
        switch ( t )
        {
            case 0:
            {
                first_3 ret = generate_first_3();
                printf ( "%d %d %d %d %d %d\n", ret.x1, ret.y1, ret.x2, ret.y2, ret.x3, ret.y3 );
                drop_first_3 ( ret );
            }
            break;
            case 1:
            {
                first_3 given;
                scanf ( "%d%d%d%d%d%d", & ( given.x1 ), & ( given.y1 ), & ( given.x2 ), & ( given.y2 ), & ( given.x3 ), & ( given.y3 ) );
                drop_first_3 ( given );
                opinion_1 ret = generate_opinion_1();
                if ( ret.opinion == 2 )
                {
                    printf ( "%d %d %d %d %d\n", ret.opinion, ret.x4, ret.y4, ret.x5, ret.y5 );
                    drop_opinion_1 ( ret );
                }
                else
                {
                    printf ( "%d\n", ret.opinion );
                }
            }
            break;
            case 2:
            {
                opinion_1 given;
                scanf ( "%d%d%d%d", & ( given.x4 ), & ( given.y4 ), & ( given.x5 ), & ( given.y5 ) );
                drop_opinion_1 ( given );
                int ret = generate_opinion_2();
                printf ( "%d\n", ret );
            }
            break;
            case 3:
            {
                int x, y;
                scanf ( "%d%d", &x, &y );
                drop ( x, y, WHITE );
                ai_subloop ( BLACK );
            }
            break;
            case 4:
            {
                ai_subloop ( WHITE );
            }
            break;
            case 5:
                resetMap();
                break;
            default:
                break;
        }
    }
    return 0;
}

void resetMap()
{
    memset ( map, 0, sizeof ( map ) );
}

int strtype ( const char* str )
{
    int i;
    for ( i = 0; i < 6; i++ )
    {
        if ( strcmp ( str, marker_str[i] ) == 0 )
        {
            return i;
        }
    }
    return 6;
}

void drop ( int x, int y, int t )
{
    map[x][y] = t;
}

void drop_first_3 ( first_3 f )
{
    drop ( f.x1, f.y1, BLACK );
    drop ( f.x2, f.y2, WHITE );
    drop ( f.x3, f.y3, BLACK );
}

void drop_opinion_1 ( opinion_1 f )
{
    drop ( f.x4, f.y4, WHITE );
    drop ( f.x5, f.y5, BLACK );
}

void ai_subloop ( int type )
{
    while ( true )
    {
        point cand = ai ( type );
        printf ( "%d %d\n", cand.x, cand.y );
        drop ( cand.x, cand.y, type );
        if ( scanf ( "%d%d", & ( cand.x ), & ( cand.y ) ) != 2 )
        {
            break;
        }
        drop ( cand.x, cand.y, SUM - type );
    }
}

// AI part

first_3 generate_first_3()
{
    first_3 ret;
    ret.x1 = 0;
    ret.y1 = 0;
    ret.x2 = 0;
    ret.y2 = 1;
    ret.x3 = 0;
    ret.y3 = 2;
    return ret;
}

opinion_1 generate_opinion_1()
{
    opinion_1 ret;
    ret.opinion = 0;
    return ret;
}

int generate_opinion_2()
{
    return 0;
}

point ai ( int type )
{
    for ( int t = 0; t < 1000; t++ )
    {
        int x = rand() % 25, y = rand() % 25;
        if ( map[x][y] == 0 )
        {
            return {.x = x, .y = y};
        }
    }
    return {0, 0};
}
