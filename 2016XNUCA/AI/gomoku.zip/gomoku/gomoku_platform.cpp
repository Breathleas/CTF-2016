/*
 * Auto generate by h2cppx
 */


#include "gomoku_platform.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

char map[32][32];

int stones = 0;

const int BLANK = 0, BLACK = 1, WHITE = 2;

const int MAPSIZE = 25;

inline void adjust ( int& x, int& y )
{
    x %= MAPSIZE;
    if ( x < 0 )
    {
        x += MAPSIZE;
    }
    y %= MAPSIZE;
    if ( y < 0 )
    {
        y += MAPSIZE;
    }
    if ( map[x][y] != 0 )
    {
        for ( int i = 0; i < MAPSIZE; i++ )
        {
            for ( int j = 0; j < MAPSIZE; j++ )
            {
                if ( map[i][j] == 0 )
                {
                    x = i;
                    y = j;
                    return;
                }
            }
        }
    }
}

bool drop ( int x, int y, int type );

void drawMap();

bool start_game_1 ( FILE* a_stdin, FILE* a_stdout, FILE* b_stdin, FILE* b_stdout );

bool game_builtin ( FILE* a_stdin, FILE* a_stdout, FILE* b_stdin, FILE* b_stdout );

bool start_one_game ( FILE* c_stdin, FILE* c_stdout, FILE* d_stdin, FILE* d_stdout )
{
    bool c_first = ( ( rand() & 1 ) != 0 );
    if ( c_first )
    {
        //fprintf ( stderr, "Challenger first\n" );
        return start_game_1 ( c_stdin, c_stdout, d_stdin, d_stdout );
    }
    else
    {
        return !start_game_1 ( d_stdin, d_stdout, c_stdin, c_stdout );
    }
}

bool start_game_1 ( FILE* a_stdin, FILE* a_stdout, FILE* b_stdin, FILE* b_stdout )
{
    // return true when a wins.
    // When draw the first one always 'win'.
    // Using swap2 rule.
    fprintf ( a_stdout, "[FIRST_3]\n" );
    int x1 = 0, y1 = 0, x2 = 1, y2 = 1, x3 = 2, y3 = 2;
    fflush ( a_stdout );
    fscanf ( a_stdin, "%d%d%d%d%d%d", &x1, &y1, &x2, &y2, &x3, &y3 );
    memset ( map, 0, sizeof ( map ) );
    adjust ( x1, y1 );
    map[x1][y1] = BLACK;
    adjust ( x2, y2 );
    map[x2][y2] = WHITE;
    adjust ( x3, y3 );
    map[x3][y3] = BLACK;
    fprintf ( b_stdout, "[YOUR_OPINION]\n%d %d %d %d %d %d\n", x1, y1, x2, y2, x3, y3 );
    int choice = 0;
    fflush ( b_stdout );
    fscanf ( b_stdin, "%d", &choice );
    stones = 3;
    if ( choice < 0 || choice > 2 )
    {
        choice = 0;
    }
    switch ( choice )
    {
        case 0:
            fprintf ( b_stdout, "[YOU_BLACK]\n" );
            fprintf ( a_stdout, "[YOU_WHITE]\n" );
            return !game_builtin ( b_stdin, b_stdout, a_stdin, a_stdout );
            break;
        case 1://tell the a to not wait and drop
            fprintf ( a_stdout, "[YOU_BLACK]\n" );
            fprintf ( b_stdout, "[YOU_WHITE]\n" );
            return game_builtin ( a_stdin, a_stdout, b_stdin, b_stdout );
            break;
        case 2:
        {
            stones += 2;
            int x4 = 0, y4 = 0, x5 = 1, y5 = 1;
            fscanf ( b_stdin, "%d%d%d%d", &x4, &y4, &x5, &y5 );
            adjust ( x4, y4 );
            map[x4][y4] = WHITE;
            adjust ( x5, y5 );
            map[x5][y5] = BLACK;
            fprintf ( a_stdout, "[YOUR_OPINION2]\n%d %d %d %d\n", x4, y4, x5, y5 );
            int choice2 = 0;
            fflush ( a_stdout );
            fscanf ( a_stdin, "%d", &choice2 );
            if ( choice2 < 0 || choice2 > 1 )
            {
                choice2 = 0;
            }
            if ( choice2 == 0 )
            {
                fprintf ( a_stdout, "[YOU_BLACK]\n" );
                fprintf ( b_stdout, "[YOU_WHITE]\n" );
                return game_builtin ( a_stdin, a_stdout, b_stdin, b_stdout );
            }
            else
            {
                fprintf ( b_stdout, "[YOU_BLACK]\n" );
                fprintf ( a_stdout, "[YOU_WHITE]\n" );
                return !game_builtin ( b_stdin, b_stdout, a_stdin, a_stdout );
            }
        }
        break;
        default:
            break;
    }
    return false;
}

bool game_builtin ( FILE* a_stdin, FILE* a_stdout, FILE* b_stdin, FILE* b_stdout )
{
    // Note that white plays first. So it is b who is the first.
    // a is black and b is white.
    int x, y;
    bool dif;
    while ( true ) //( stones < MAPSIZE * MAPSIZE )
    {
        fflush ( b_stdout );
        drawMap();
        fscanf ( b_stdin, "%d%d", &x, &y );
        adjust ( x, y );
        dif = drop ( x, y, WHITE );
        if ( dif )
        {
            fprintf ( a_stdout, "[GAME_OVER]\n" );
            fprintf ( b_stdout, "[GAME_OVER]\n" );
            return false;
        }
        if ( stones >= MAPSIZE * MAPSIZE )
        {
            break;
        }
        fprintf ( a_stdout, "%d %d\n", x, y );
        fflush ( a_stdout );
        drawMap();
        fscanf ( a_stdin, "%d%d", &x, &y );
        adjust ( x, y );
        dif = drop ( x, y, BLACK );
        if ( dif )
        {
            fprintf ( a_stdout, "[GAME_OVER]\n" );
            fprintf ( b_stdout, "[GAME_OVER]\n" );
            return true;
        }
        if ( stones >= MAPSIZE * MAPSIZE )
        {
            break;
        }
        fprintf ( b_stdout, "%d %d\n", x, y );
    }
    fprintf ( a_stdout, "[GAME_OVER]\n" );
    fprintf ( b_stdout, "[GAME_OVER]\n" );
    return true;
}

bool drop ( int x, int y, int type )
{
    if ( map[x][y] != BLANK )
    {
        fprintf ( stderr, "Exception! maybe the map is full. The place to drop is invalid." );
        return false;
    }
    stones++;
    map[x][y] = type;
    int dir_x[8] = {0, 1, 1, 1, 0, MAPSIZE - 1, MAPSIZE - 1, MAPSIZE - 1};
    int dir_y[8] = {1, 1, 0, MAPSIZE - 1, MAPSIZE - 1, MAPSIZE - 1, 0, 1};
    int tentacle[8];
    for ( int i = 0; i < 8; i++ )
    {
        tentacle[i] = 8;
        for ( int j = 0; j < 8; j++ )
        {
            int xx = ( x + dir_x[i] * j ) % MAPSIZE;
            int yy = ( y + dir_y[i] * j ) % MAPSIZE;
            if ( map[xx][yy] != type )
            {
                tentacle[i] = j;
                break;
            }
        }
    }
    for ( int i = 0; i < 4; i++ )
    {
        if ( tentacle[i] + tentacle[i + 4] == 6 )
        {
            return true;
        }
    }
    return false;
}

void drawMap()
{
#ifdef DEBUG
    for ( int i = -10; i < MAPSIZE + 10; i++ )
    {
        for ( int j = -10; j < MAPSIZE + 10; j++ )
        {
            int r_i = i % MAPSIZE;
            if ( r_i < 0 )
            {
                r_i += MAPSIZE;
            }
            int r_j = j % MAPSIZE;
            if ( r_j < 0 )
            {
                r_j += MAPSIZE;
            }
            switch ( map[r_i][r_j] )
            {
                case BLANK:
                    if ( i == r_i && j == r_j )
                    {
                        fprintf ( stderr, "  " );
                    }
                    else
                    {
                        fprintf ( stderr, "\e[44m  \e[49m" );
                    }
                    break;
                case BLACK:
                    fprintf ( stderr, "\e[40m[]\e[49m" );
                    break;
                case WHITE:
                    fprintf ( stderr, "\e[47m[]\e[49m" );
                    break;
            }
        }
        fprintf ( stderr, "\n" );
    }
#endif
}

#ifdef DEBUG_MAIN

int main()
{
    start_one_game ( stdin, stdout, stdin, stdout );
}

#endif
