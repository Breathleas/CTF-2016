#include <stdio.h>
#include <stdlib.h> // rand, srand, atoi
#include <time.h>   // time(0)

#include <unistd.h> // alarm
#include <signal.h>

int score = 0;

void alarm_handler ( int signo )
{
    ( void ) signo;
    fprintf ( stderr, "SCORE:[%d]\n", score );
    exit ( 0 );
}

int pattern1 ( int a, int b, int c )
{
    return ( a + b + c / 2 ) % c;
}

int pattern2 ( int a, int b, int c )
{
    return ( a - b ) ^c;
}

int pattern3 ( int a, int b, int c )
{
    return ( a ^ c ) + ~ ( b & c );
}

int pattern4 ( int a, int b, int c )
{
    return ( a % c ) ^ ( b % c );
}

typedef int ( *func ) ( int, int, int );

func patterns[4] = {pattern1, pattern2, pattern3, pattern4};

int main ( int argc, char* argv[] )
{
    srand ( time ( 0 ) );
    if ( argc != 2 )
    {
ARG_FAIL:
        fprintf ( stderr, "Usage: %s [case number], where the number should be between 0 and 3.\n", argv[0] );
        return -1;
    }
    int pattern_id = atoi ( argv[1] );
    if ( pattern_id < 0 || pattern_id >= 4 )
    {
        goto ARG_FAIL;
    }
    alarm ( 60 * 1 );
    if ( signal ( SIGALRM, alarm_handler ) == SIG_ERR )
    {
        fprintf ( stderr, "Failed to set the alarm!\n" );
        return -1;
    }
    // The real topic.
    func pattern = patterns[pattern_id];
    printf ( "This is an easy challenge. We want to make sure that "
             "you know the rule of the whole competition, and that "
             "you use the pipe correctly. :)\n"
             "====================================================\n"
             "Challenge: Find Pattern\n" );
    int secret_c = rand() % 257 + 257;
    //fprintf(stderr,"c=%d\n",secret_c);
    for ( int t = 0; t < 10; t++ )
    {
        int a = rand() % 65537, b = rand() % 65537;
        printf ( "[%d] %d # %d = %d ;\n", t, a, b, pattern ( a, b, secret_c ) );
    }
    printf ( "Now calculate: \n" );
    for ( int t = 0; t < 100; t++ )
    {
        int a = rand() % 65537, b = rand() % 65537;
        int res, correct_ans;
        printf ( "[%d] %d # %d ;\n", t, a, b );
        fflush ( stdout );
        scanf ( "%d", &res );
        correct_ans = pattern ( a, b, secret_c );
        if ( res == correct_ans )
        {
            score += 10;
            printf ( "Correct!\n" );
        }
        else
        {
            printf ( "Wrong!\n" );
        }
    }
    alarm ( 60 );
    printf ( "Your score: %d. Congratulations~\n", score );
    fprintf ( stderr, "SCORE:[%d]\n", score );
    return 0;
}
