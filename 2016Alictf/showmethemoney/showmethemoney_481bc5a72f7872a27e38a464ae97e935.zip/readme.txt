Show me the money to decrypt it.
ID:		09ce12e1-b775-4bda-af37-8abd886478ee
Filename:	flag.txt
